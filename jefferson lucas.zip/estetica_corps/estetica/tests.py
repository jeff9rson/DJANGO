from django.test import TestCase

# Create your tests here.
