from django.contrib import admin
from .models import Estetica

admin.site.register(Estetica)
